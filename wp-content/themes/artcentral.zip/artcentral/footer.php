<?php wp_footer();?>
<footer>
  <?php if( is_active_sidebar('min-sidebar') ) : ?>
    <?php dynamic_sidebar('min-sidebar'); ?>
  <?php endif;?>
</footer>
</body>
</html>
