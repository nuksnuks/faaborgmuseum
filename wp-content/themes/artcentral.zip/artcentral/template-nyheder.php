<?php
/*
Template Name: Nyheder
*/
?>
<?php get_header(); ?>

<section class="indhold">

<div class="container">
  <?php get_template_part('includes/section', 'nyheder');?>
</div>

</section>

<?php get_footer(); ?>
