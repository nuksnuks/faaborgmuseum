 <?php get_header(); ?>

<section class="indhold">
<div class="container">
  <?php get_template_part('includes/section', 'frontcontent');?>

</div>

</section>

<?php get_footer(); ?>
